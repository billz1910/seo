<?php
/**
 * fetch.php — Sitemap Generator
 * 
 * Membaca kw.txt dan menghasilkan sitemap XML untuk semua halaman.
 * Jalankan via browser : domain.com/media/fetch.php  (auto-detect lokasi)
 * Jalankan via CLI    : php fetch.php domainku.com /media
 * Hasil: sitemap-index.xml + sitemap-1.xml, sitemap-2.xml, ... (jika > 10000 URL)
 */

$protocol  = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");

// Deteksi host & direktori deploy secara otomatis (bisa /media/, /ggez/, root, dll)
if (PHP_SAPI === 'cli') {
    $host_name  = $argv[1] ?? '';
    $script_dir = $argv[2] ?? '';
} else {
    $host_name  = $_SERVER['HTTP_HOST'] ?? '';
    $script_dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/fetch.php'));
}
$script_dir = rtrim($script_dir, '/');
if ($script_dir === '/' || $script_dir === '\\' || $script_dir === '') {
    $script_dir = '';
}

$base_path  = $protocol . "://" . $host_name;
$domain_url = $base_path . $script_dir . '/';
$base_url   = $base_path . $script_dir . '/?video=';

$sitemap_name = 'sitemap';
$max_links_per_sitemap = 10000;
$local_file = 'kw.txt';

// --- Read keywords ---
if (!file_exists($local_file)) {
    die("ERROR: {$local_file} not found.\n");
}

$raw_lines = file($local_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$keywords = array_map('trim', $raw_lines);
$keywords = array_filter($keywords);

if (empty($keywords)) {
    die("ERROR: No valid keywords found in {$local_file}\n");
}

$total_keywords = count($keywords);
echo "Found {$total_keywords} keywords in {$local_file}\n";

// --- Build sitemap index header ---
$sitemap_index  = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
$sitemap_index .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;

$sitemap_files = [];
$lastmod = date('Y-m-d');

foreach ($keywords as $i => $keyword) {
    // Clean and encode keyword for URL
    $clean_keyword = str_replace(' ', '+', $keyword);
    $encoded_keyword = $clean_keyword;

    $sitemap_num = (int) ceil(($i + 1) / $max_links_per_sitemap);

    // Initialize new sitemap file content
    if (!isset($sitemap_files[$sitemap_num])) {
        $sitemap_files[$sitemap_num]  = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
        $sitemap_files[$sitemap_num] .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;
    }

    $full_url = $base_url . $encoded_keyword;
    $escaped_url = htmlspecialchars($full_url, ENT_XML1, 'UTF-8');

    $sitemap_files[$sitemap_num] .= "  <url>" . PHP_EOL;
    $sitemap_files[$sitemap_num] .= "    <loc>{$escaped_url}</loc>" . PHP_EOL;
    $sitemap_files[$sitemap_num] .= "    <lastmod>{$lastmod}</lastmod>" . PHP_EOL;
    $sitemap_files[$sitemap_num] .= "    <changefreq>weekly</changefreq>" . PHP_EOL;
    $sitemap_files[$sitemap_num] .= "    <priority>0.8</priority>" . PHP_EOL;
    $sitemap_files[$sitemap_num] .= "  </url>" . PHP_EOL;
}

// --- Write sitemap files and build index ---
$total_files = 0;
foreach ($sitemap_files as $num => &$content) {
    $content .= '</urlset>' . PHP_EOL;
    $file_name = "{$sitemap_name}-{$num}.xml";
    file_put_contents($file_name, $content);
    $total_files++;

    $sitemap_index .= "  <sitemap>" . PHP_EOL;
    $sitemap_index .= "    <loc>" . htmlspecialchars($domain_url . $file_name, ENT_XML1, 'UTF-8') . "</loc>" . PHP_EOL;
    $sitemap_index .= "    <lastmod>{$lastmod}</lastmod>" . PHP_EOL;
    $sitemap_index .= "  </sitemap>" . PHP_EOL;
}

// --- Write sitemap index ---
$sitemap_index .= '</sitemapindex>' . PHP_EOL;
file_put_contents("sitemap-index.xml", $sitemap_index);

echo "DONE: {$total_keywords} URLs across {$total_files} sitemap file(s).\n";
echo "Submit sitemap-index.xml to Google Search Console.\n";