<?php
header('Content-Type: text/html; charset=utf-8');

// ============================================================
// 1. LOAD CONFIGURATION
// ============================================================
require_once 'config.php';

// ============================================================
// DETEKSI DIREKTORI DEPLOY SECARA OTOMATIS
// (bisa /media/, /ggez/, /shop/, root, dll — tanpa hardcode)
// ============================================================
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
if ($scriptDir === '/' || $scriptDir === '\\' || $scriptDir === '') {
    $scriptDir = '';
}

// ============================================================
// IDENTITAS SITUS UNIK (host + direktori) — dipakai sebagai
// seed konten agar tiap domain/direktori menghasilkan konten
// yang berbeda (anti duplicate content)
// ============================================================
$siteKey = ($_SERVER['HTTP_HOST'] ?? '') . '|' . $scriptDir;

// ============================================================
// 2. PROCESS 'video' PARAMETER & BUILD CANONICAL URL
// ============================================================
$BRAND  = '';
$NUMLIST = 0;
$incomingSlug = '';

if (isset($_GET['video'])) {
    $incomingRaw = rawurldecode(trim((string)$_GET['video']));
    $incomingLower = mb_strtolower($incomingRaw, 'UTF-8');
    $incomingSlug = str_replace(' ', '-', $incomingLower);

    if ($incomingSlug === '') {
        header("HTTP/1.1 404 Not Found");
        exit("ไม่พบพารามิเตอร์ 'video'");
    }

    $brandListFile = __DIR__ . '/kw.txt';
    if (!is_readable($brandListFile)) {
        header("HTTP/1.1 500 Internal Server Error");
        exit("ข้อผิดพลาด: ไม่พบ 'kw.txt' หรือไม่สามารถอ่านได้");
    }

    $lines = file($brandListFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lines as $i => $line) {
        $candidateRaw = trim(rawurldecode($line));
        $candidateLower = mb_strtolower($candidateRaw, 'UTF-8');
        $slug = str_replace(' ', '-', $candidateLower);

        if ($slug === $incomingSlug) {
            $BRAND = strtoupper($candidateLower);
            $NUMLIST = $i + 1;
            break;
        }
    }

    if ($BRAND === '') {
        header("HTTP/1.1 410 Gone");
        exit("ไม่พบแบรนด์ '{$incomingRaw}'");
    }
} else {
    // ============================================================
    // NO 'video' PARAMETER — TAMPILKAN LANDING PAGE PENUH (SEO)
    // ============================================================
    $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
    $host     = $_SERVER['HTTP_HOST'];
    $canonicalUrl = $protocol . "://" . $host . $scriptDir . "/";
    $destUrl = htmlspecialchars($destinationUrl, ENT_QUOTES, 'UTF-8');

    // Konten LP berbeda per situs (seed = host + direktori) — tidak duplicate antar domain
    $lpSeed  = crc32($siteKey);
    $lpImg   = $images[$lpSeed % count($images)];
    $lpTag   = $taglines[($lpSeed + 5) % count($taglines)];
    $lpName  = htmlspecialchars((isset($siteName) && $siteName !== '') ? $siteName : 'LEX818', ENT_QUOTES, 'UTF-8');
    $lpTitleText = $randomTitles[($lpSeed + 9) % count($randomTitles)];
    $lpDescText  = $randomDescriptions[($lpSeed + 21) % count($randomDescriptions)];
    $lpBlock1 = $contentBlocks[$lpSeed % count($contentBlocks)];
    $lpBlock2 = $contentBlocks[($lpSeed + 17) % count($contentBlocks)];

    // Gambar popup khusus LP (poplim) — deterministik per domain
    $lpPopupImg = $popupImages[($lpSeed + 7) % count($popupImages)];

    // FAQ LP (seed = domain)
    $lpFaqs = [
        ["{$lpName} คืออะไร?", "{$lpName} เป็นแพลตฟอร์มเกมออนไลน์ครบวงจรที่มีตัวเลือกเกมสนุกหลากหลาย ถูกออกแบบมาเพื่อมอบประสบการณ์ที่ปลอดภัย สะดวกสบาย และสนุกสนาน พร้อมเทคโนโลยีทันสมัยรองรับผู้ใช้ทุกคน"],
        ["วิธีสมัครสมาชิก {$lpName} ทำอย่างไร?", "เพียงกรอกแบบฟอร์มสมัครในหน้าเว็บ กระบวนการใช้เวลาไม่กี่นาที หลังบัญชีเปิดใช้งานแล้ว คุณสามารถสนุกกับบริการทั้งหมดของ {$lpName} ได้ทันที"],
        ["{$lpName} ปลอดภัยหรือไม่?", "ปลอดภัยแน่นอน {$lpName} ใช้ระบบเข้ารหัส SSL ล่าสุดเพื่อปกป้องข้อมูลส่วนตัวและธุรกรรมของคุณ ความเป็นส่วนตัวของผู้ใช้คือสิ่งสำคัญสูงสุดของเรา"],
        ["ฝาก-ถอนเงินกับ {$lpName} รวดเร็วแค่ไหน?", "รองรับธนาคารในประเทศ ทรูมันนี่ วอลเลท และคิวอาร์โค้ด ระบบฝาก-ถอนอัตโนมัติ ใช้เวลาไม่เกิน 1 นาที ไม่มีค่าธรรมเนียม"],
        ["{$lpName} มีโปรโมชั่นอะไรบ้าง?", "มีโบนัสสมาชิกใหม่ 100% โบนัสฝากรายวัน คืนยอดเสียรายสัปดาห์ ฟรีสปิน และโบนัสแนะนำเพื่อน ติดตามโปรโมชั่นล่าสุดได้ที่หน้าเว็บไซต์"],
        ["{$lpName} รองรับอุปกรณ์อะไรบ้าง?", "รองรับทุกอุปกรณ์ทั้งคอมพิวเตอร์ แท็บเล็ต และสมาร์ตโฟน ระบบ iOS และ Android เล่นได้ทุกที่ทุกเวลาโดยไม่ต้องติดตั้งแอปพลิเคชันเพิ่มเติม"],
    ];
    $lpFaqI1 = $lpSeed % count($lpFaqs);
    $lpFaqI2 = ($lpSeed + 11) % count($lpFaqs);
    $lpFaqI3 = ($lpSeed + 22) % count($lpFaqs);
    while ($lpFaqI2 === $lpFaqI1) { $lpFaqI2 = ($lpFaqI2 + 1) % count($lpFaqs); }
    while ($lpFaqI3 === $lpFaqI1 || $lpFaqI3 === $lpFaqI2) { $lpFaqI3 = ($lpFaqI3 + 1) % count($lpFaqs); }
    $lpFaqSel = [$lpFaqs[$lpFaqI1], $lpFaqs[$lpFaqI2], $lpFaqs[$lpFaqI3]];
    ?>
    <!DOCTYPE html>
    <html lang="th">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="index, follow">
        <title><?= htmlspecialchars($lpTitleText, ENT_QUOTES, 'UTF-8') ?></title>
        <meta name="description" content="<?= htmlspecialchars($lpDescText, ENT_QUOTES, 'UTF-8') ?>">
        <meta name="author" content="<?= $lpName ?>">
        <link rel="canonical" href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>">

        <!-- Open Graph -->
        <meta property="og:title" content="<?= htmlspecialchars($lpTitleText, ENT_QUOTES, 'UTF-8') ?>">
        <meta property="og:description" content="<?= htmlspecialchars($lpDescText, ENT_QUOTES, 'UTF-8') ?>">
        <meta property="og:type" content="website">
        <meta property="og:url" content="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>">
        <meta property="og:image" content="<?= htmlspecialchars($lpImg, ENT_QUOTES, 'UTF-8') ?>">
        <meta property="og:site_name" content="<?= $lpName ?>">
        <meta property="og:locale" content="th_TH">

        <!-- Structured Data: FAQ -->
        <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                <?php foreach ($lpFaqSel as $idx => $faq): ?>
                {
                    "@type": "Question",
                    "name": "<?= htmlspecialchars($faq[0], ENT_QUOTES, 'UTF-8') ?>",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "<?= htmlspecialchars($faq[1], ENT_QUOTES, 'UTF-8') ?>"
                    }
                }<?= $idx < count($lpFaqSel) - 1 ? ',' : '' ?>
                <?php endforeach; ?>
            ]
        }
        </script>

        <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            html { scroll-behavior: smooth; }
            body {
                font-family: 'Kanit', 'Sarabun', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                line-height: 1.8;
                color: #222;
                background: #f8f9fa;
                -webkit-font-smoothing: antialiased;
            }
            a { text-decoration: none; }
            img { max-width: 100%; height: auto; display: block; }
            .lp-wrap { max-width: 1100px; margin: 0 auto; padding: 0 1.25rem; }

            /* Header */
            .lp-header {
                background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
                color: #fff;
                padding: 1rem 0;
                position: sticky;
                top: 0;
                z-index: 100;
                box-shadow: 0 2px 15px rgba(0,0,0,0.25);
            }
            .lp-header__inner {
                display: flex;
                align-items: center;
                justify-content: space-between;
                flex-wrap: wrap;
                gap: 1rem;
            }
            .lp-header__logo {
                font-size: 1.6rem;
                font-weight: 900;
                letter-spacing: 1px;
                background: linear-gradient(180deg, #ffd54f 0%, #ff9800 60%, #e65100 100%);
                -webkit-background-clip: text;
                background-clip: text;
                color: transparent;
                filter: drop-shadow(0 0 12px rgba(255,152,0,0.45));
            }
            .lp-header__nav { display: flex; gap: 1.25rem; flex-wrap: wrap; }
            .lp-header__nav a { color: #ccc; font-size: 0.9rem; font-weight: 500; }
            .lp-header__nav a:hover { color: #ffd54f; }

            /* Hero */
            .lp-hero {
                background: radial-gradient(ellipse at 50% 0%, #2a1a4a 0%, #150f2e 55%, #0a0716 100%);
                color: #fff;
                text-align: center;
                padding: 3.5rem 1.25rem 3rem;
                border-bottom: 4px solid #ff9800;
            }
            .lp-hero__title {
                font-size: 2.3rem;
                font-weight: 800;
                color: #ffd54f;
                line-height: 1.25;
                text-shadow: 0 0 25px rgba(255,213,79,0.4);
            }
            .lp-hero__big {
                font-size: 3.6rem;
                font-weight: 900;
                color: #fff;
                line-height: 1.1;
                text-shadow: 0 0 30px rgba(255,255,255,0.35);
            }
            .lp-hero__sub {
                font-size: 1.05rem;
                color: #ffd54f;
                margin: 1rem auto 1.5rem;
                max-width: 620px;
            }
            .lp-hero__img {
                width: 100%;
                max-width: 520px;
                margin: 0 auto 1.75rem;
                border-radius: 18px;
                box-shadow: 0 15px 50px rgba(0,0,0,0.55), 0 0 0 3px rgba(255,213,79,0.25);
                transition: transform 0.3s;
            }
            .lp-hero__img:hover { transform: scale(1.02); }
            .lp-hero__cta {
                display: flex;
                gap: 1rem;
                justify-content: center;
                flex-wrap: wrap;
            }
            .lp-hero__btn {
                flex: 1 1 200px;
                max-width: 240px;
                display: inline-block;
                padding: 1.1rem 1.5rem;
                border-radius: 50px;
                font-size: 1.2rem;
                font-weight: 800;
                letter-spacing: 0.3px;
                transition: all 0.3s;
            }
            .lp-hero__btn--green {
                background: linear-gradient(135deg, #4CAF50, #2E7D32);
                color: #fff;
                box-shadow: 0 6px 20px rgba(76,175,80,0.4);
            }
            .lp-hero__btn--blue {
                background: linear-gradient(135deg, #2196F3, #1565C0);
                color: #fff;
                box-shadow: 0 6px 20px rgba(33,150,243,0.4);
            }
            .lp-hero__btn:hover { transform: translateY(-3px); filter: brightness(1.1); color: #fff; }

            /* Features */
            .lp-features { padding: 2.5rem 0 1rem; }
            .lp-features__grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
                gap: 1.25rem;
            }
            .lp-feature {
                background: #fff;
                border-radius: 14px;
                padding: 1.5rem 1.25rem;
                text-align: center;
                box-shadow: 0 2px 12px rgba(0,0,0,0.07);
                border-top: 4px solid #ff9800;
            }
            .lp-feature__icon { font-size: 2.2rem; margin-bottom: 0.4rem; }
            .lp-feature__title { font-size: 1.05rem; font-weight: 700; color: #1a1a2e; margin-bottom: 0.3rem; }
            .lp-feature__desc { font-size: 0.88rem; color: #666; }

            /* About */
            .lp-about { padding: 1.5rem 0; }
            .lp-about h2 {
                font-size: 1.7rem;
                color: #1a1a2e;
                margin-bottom: 1rem;
                padding-bottom: 0.5rem;
                border-bottom: 3px solid #ff9800;
                display: inline-block;
            }
            .lp-about p { color: #444; margin-bottom: 1rem; text-align: justify; }
            .lp-about ul { margin: 1rem 0 1.5rem 1.5rem; color: #444; }
            .lp-about ul li { margin-bottom: 0.4rem; }
            .lp-about__cta {
                display: flex;
                gap: 1rem;
                justify-content: center;
                flex-wrap: wrap;
                margin: 2rem 0 1rem;
            }

            /* FAQ */
            .lp-faq { padding: 1rem 0 2.5rem; }
            .lp-faq h2 {
                font-size: 1.7rem;
                color: #1a1a2e;
                margin-bottom: 1.25rem;
                padding-bottom: 0.5rem;
                border-bottom: 3px solid #ff9800;
                display: inline-block;
            }
            .lp-faq details {
                background: #fff;
                border-radius: 10px;
                margin-bottom: 0.75rem;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
                overflow: hidden;
            }
            .lp-faq summary {
                padding: 1rem 1.5rem;
                font-weight: 700;
                cursor: pointer;
                color: #1a1a2e;
                display: flex;
                justify-content: space-between;
                align-items: center;
                user-select: none;
            }
            .lp-faq summary::after { content: '+'; font-size: 1.3rem; color: #999; }
            .lp-faq details[open] summary::after { content: '−'; color: #ff9800; }
            .lp-faq .lp-faq__answer { padding: 0 1.5rem 1.2rem; color: #555; font-size: 0.95rem; }

            /* Footer */
            .lp-footer {
                background: #1a1a2e;
                color: #888;
                text-align: center;
                padding: 2rem 1.25rem;
                font-size: 0.85rem;
            }
            .lp-footer__brand { color: #ffd54f; font-weight: 800; font-size: 1.1rem; }
            .lp-footer__disclaimer {
                max-width: 700px;
                margin: 0.75rem auto 0;
                font-size: 0.8rem;
                color: #666;
            }

            @media (max-width: 600px) {
                .lp-hero__title { font-size: 1.8rem; }
                .lp-hero__big { font-size: 2.6rem; }
                .lp-hero { padding: 2.5rem 1.25rem 2.25rem; }
            }

            /* Popup (muncul setiap load — sama seperti halaman SEO) */
            .popup {
                position: fixed;
                inset: 0;
                z-index: 9999;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 1rem;
            }
            .popup__overlay {
                position: absolute;
                inset: 0;
                background: rgba(0, 0, 0, 0.8);
            }
            .popup__box {
                position: relative;
                background: #fff;
                border-radius: 16px;
                max-width: 420px;
                width: 100%;
                padding: 1.5rem;
                text-align: center;
                box-shadow: 0 20px 60px rgba(0,0,0,0.5);
                animation: popupIn 0.4s ease;
                max-height: 90vh;
                overflow-y: auto;
            }
            @keyframes popupIn {
                from { transform: translateY(40px); opacity: 0; }
                to   { transform: translateY(0);   opacity: 1; }
            }
            .popup__close {
                position: absolute;
                top: 0.75rem;
                right: 0.75rem;
                width: 34px;
                height: 34px;
                border-radius: 50%;
                border: none;
                background: #f0f0f0;
                color: #333;
                font-size: 1rem;
                font-weight: 700;
                cursor: pointer;
                transition: all 0.2s;
            }
            .popup__close:hover { background: #ff9800; color: #fff; }
            .popup__brand {
                font-size: 1.4rem;
                font-weight: 800;
                color: #1a1a2e;
                margin-bottom: 0.25rem;
            }
            .popup__brand span { color: #ff9800; }
            .popup__head {
                font-size: 1.1rem;
                font-weight: 700;
                color: #ff9800;
                margin-bottom: 1rem;
            }
            .popup__img {
                width: 100%;
                border-radius: 12px;
                margin-bottom: 1rem;
                box-shadow: 0 6px 20px rgba(0,0,0,0.15);
                transition: transform 0.3s;
            }
            .popup__img:hover { transform: scale(1.03); }
            .popup__slogan {
                font-size: 0.95rem;
                color: #555;
                margin-bottom: 1rem;
            }
            .popup__cta-row {
                display: flex;
                gap: 0.7rem;
            }
            .popup__cta {
                flex: 1;
                background: linear-gradient(135deg, #2196F3, #1976D2);
                color: #fff;
                padding: 0.95rem 0.5rem;
                border-radius: 50px;
                font-weight: 800;
                font-size: 1.05rem;
                text-align: center;
                transition: all 0.3s;
            }
            .popup__cta--green { background: linear-gradient(135deg, #4CAF50, #388E3C); }
            .popup__cta:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 25px rgba(33,150,243,0.4);
                color: #fff;
            }
            .popup__cta--green:hover { box-shadow: 0 8px 25px rgba(76,175,80,0.4); }
        </style>
    </head>
    <body>

    <!-- HEADER -->
    <header class="lp-header">
        <div class="lp-wrap lp-header__inner">
            <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>" class="lp-header__logo"><?= $lpName ?></a>
            <nav class="lp-header__nav">
                <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>">หน้าแรก</a>
                <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>#เกี่ยวกับ">เกี่ยวกับ</a>
                <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>#faq">คำถามที่พบบ่อย</a>
                <a href="<?= $destUrl ?>" rel="nofollow">ติดต่อ</a>
            </nav>
        </div>
    </header>

    <!-- HERO -->
    <section class="lp-hero">
        <h1 class="lp-hero__title">สล็อต PG เว็บตรง</h1>
        <div class="lp-hero__big">แตกหนัก</div>
        <p class="lp-hero__sub"><?= htmlspecialchars($lpTag, ENT_QUOTES, 'UTF-8') ?> — รวดเร็วที่สุด ฝาก-ถอนอัตโนมัติ</p>
        <a href="<?= $destUrl ?>" rel="nofollow" aria-label="สมัครสมาชิก">
            <img class="lp-hero__img" src="<?= htmlspecialchars($lpImg, ENT_QUOTES, 'UTF-8') ?>" alt="สล็อต PG เว็บตรง แตกหนัก <?= $lpName ?>" width="520" height="520">
        </a>
        <div class="lp-hero__cta">
            <a href="<?= $destUrl ?>" class="lp-hero__btn lp-hero__btn--green" rel="nofollow">เข้าสู่ระบบ</a>
            <a href="<?= $destUrl ?>" class="lp-hero__btn lp-hero__btn--blue" rel="nofollow">สมัครสมาชิก</a>
        </div>
    </section>

    <!-- FEATURES -->
    <section class="lp-features">
        <div class="lp-wrap lp-features__grid">
            <div class="lp-feature">
                <div class="lp-feature__icon">⚡</div>
                <div class="lp-feature__title">ฝาก-ถอนอัตโนมัติ</div>
                <div class="lp-feature__desc">ทำรายการรวดเร็ว ไม่เกิน 1 นาที ไม่มีค่าธรรมเนียม</div>
            </div>
            <div class="lp-feature">
                <div class="lp-feature__icon">🕐</div>
                <div class="lp-feature__title">บริการ 24 ชั่วโมง</div>
                <div class="lp-feature__desc">ทีมงานมืออาชีพพร้อมให้บริการตลอดเวลา</div>
            </div>
            <div class="lp-feature">
                <div class="lp-feature__icon">🔒</div>
                <div class="lp-feature__title">ระบบความปลอดภัย SSL</div>
                <div class="lp-feature__desc">ปกป้องข้อมูลส่วนตัวและธุรกรรมของคุณ</div>
            </div>
            <div class="lp-feature">
                <div class="lp-feature__icon">🎁</div>
                <div class="lp-feature__title">โบนัสสมาชิกใหม่ 100%</div>
                <div class="lp-feature__desc">โปรโมชั่นพิเศษมากมายรอคุณอยู่ทุกวัน</div>
            </div>
        </div>
    </section>

    <!-- ABOUT -->
    <section class="lp-about" id="เกี่ยวกับ">
        <div class="lp-wrap">
            <h2>เกี่ยวกับ <?= $lpName ?></h2>
            <p><?= htmlspecialchars($lpBlock1, ENT_QUOTES, 'UTF-8') ?></p>
            <p><?= htmlspecialchars($lpBlock2, ENT_QUOTES, 'UTF-8') ?></p>
            <ul>
                <li>เข้าถึงง่ายและรวดเร็วผ่านทุกอุปกรณ์</li>
                <li>ความปลอดภัยของข้อมูลรับประกันด้วยระบบ SSL</li>
                <li>บริการลูกค้า 24 ชั่วโมงไม่หยุด</li>
                <li>กระบวนการธุรกรรมที่รวดเร็วทันใจ</li>
                <li>โบนัสและโปรโมชั่นมากมายทุกวัน</li>
            </ul>
            <div class="lp-about__cta">
                <a href="<?= $destUrl ?>" class="lp-hero__btn lp-hero__btn--green" rel="nofollow">เข้าสู่ระบบ</a>
                <a href="<?= $destUrl ?>" class="lp-hero__btn lp-hero__btn--blue" rel="nofollow">สมัครสมาชิก</a>
            </div>
        </div>
    </section>

    <!-- FAQ -->
    <section class="lp-faq" id="faq">
        <div class="lp-wrap">
            <h2>คำถามที่พบบ่อยเกี่ยวกับ <?= $lpName ?></h2>
            <?php foreach ($lpFaqSel as $faq): ?>
            <details>
                <summary><?= htmlspecialchars($faq[0], ENT_QUOTES, 'UTF-8') ?></summary>
                <div class="lp-faq__answer">
                    <p><?= htmlspecialchars($faq[1], ENT_QUOTES, 'UTF-8') ?></p>
                </div>
            </details>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- FOOTER -->
    <footer class="lp-footer">
        <div class="lp-wrap">
            <div class="lp-footer__brand"><?= $lpName ?></div>
            <p>&copy; <?= date('Y') ?> <?= $lpName ?>. สงวนลิขสิทธิ์ทั้งหมด</p>
            <p class="lp-footer__disclaimer">
                หน้านี้ให้ข้อมูลทั่วไปเกี่ยวกับ <?= $lpName ?> เนื้อหามีวัตถุประสงค์เพื่อให้ข้อมูลเท่านั้น
                <?= $lpName ?> เป็น <?= htmlspecialchars($lpTag, ENT_QUOTES, 'UTF-8') ?>
            </p>
        </div>
    </footer>

    <!-- POPUP (muncul setiap load — sama seperti halaman SEO) -->
    <div class="popup" id="popupFooter" style="display:none;">
        <div class="popup__overlay" onclick="closeFooterPopup()"></div>
        <div class="popup__box">
            <button class="popup__close" onclick="closeFooterPopup()" aria-label="ปิด">✕</button>
            <div class="popup__brand"><?= $lpName ?></div>
            <div class="popup__head">🎁 โปรโมชั่นพิเศษวันนี้</div>
            <a href="<?= $destUrl ?>" rel="nofollow" aria-label="สมัครสมาชิก">
                <img class="popup__img" src="<?= htmlspecialchars($lpPopupImg, ENT_QUOTES, 'UTF-8') ?>" alt="โปรโมชั่น <?= $lpName ?>" width="420" height="420">
            </a>
            <div class="popup__slogan"><?= htmlspecialchars($lpTag, ENT_QUOTES, 'UTF-8') ?> — รับโบนัสสูงสุดทันที</div>
            <div class="popup__cta-row">
                <a href="<?= $destUrl ?>" class="popup__cta popup__cta--green" rel="nofollow">เข้าสู่ระบบ</a>
                <a href="<?= $destUrl ?>" class="popup__cta" rel="nofollow">สมัครสมาชิก</a>
            </div>
        </div>
    </div>

    <script>
        function closeFooterPopup() {
            document.getElementById('popupFooter').style.display = 'none';
        }
        // Popup selalu muncul setiap kali halaman dimuat / di-refresh
        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('popupFooter').style.display = 'flex';
        });
    </script>

    </body>
    </html>
    <?php
    exit();
}

// ============================================================
// 3. BUILD CANONICAL URL
// ============================================================
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
$host     = $_SERVER['HTTP_HOST'];
$canonicalUrl = $protocol . "://" . $host . $scriptDir . "/?video=" . $incomingSlug;

// ============================================================
// 4. SEED-BASED RANDOMIZATION
// ============================================================
$seed = crc32($incomingSlug . '|' . $siteKey);
srand($seed);

// Random indexes
$emojiIndex   = $seed % count($emojis);
$taglineIndex = ($seed + 3) % count($taglines);
$imgIndex     = ($seed + 13) % count($images);
$titleIndex   = ($seed + 19) % count($randomTitles);
$descIndex    = ($seed + 23) % count($randomDescriptions);

// Pick 3 unique content blocks
$totalBlocks = count($contentBlocks);
$block1Index = $seed % $totalBlocks;
$block2Index = ($seed + 17) % $totalBlocks;
$block3Index = ($seed + 31) % $totalBlocks;
while ($block2Index === $block1Index) { $block2Index = ($block2Index + 1) % $totalBlocks; }
while ($block3Index === $block1Index || $block3Index === $block2Index) { $block3Index = ($block3Index + 1) % $totalBlocks; }

// Random price (between 50,000 - 500,000 THB)
$randomPrice = number_format(rand(50000, 500000), 0, '.', ',');

// Random SKU (termasuk identitas situs agar unik di setiap stock domain)
$randomSKU = 'SLOT-' . strtoupper(substr(md5($incomingSlug . '|' . $siteKey), 0, 8));

$randomEmoji      = $emojis[$emojiIndex];
$randomTagline    = $taglines[$taglineIndex];
$randomImg        = $images[$imgIndex];
$randomTitleText  = $randomTitles[$titleIndex];
$randomDescText   = $randomDescriptions[$descIndex];
$contentBlock1    = $contentBlocks[$block1Index];
$contentBlock2    = $contentBlocks[$block2Index];
$contentBlock3    = $contentBlocks[$block3Index];

// Gambar khusus POPUP (poplim) — deterministik per domain
$popupImgIndex = ($seed + 41) % count($popupImages);
$popupImg = $popupImages[$popupImgIndex];

// Semua elemen halaman (emoji, tagline, gambar, judul, deskripsi,
// blok konten, harga, SKU, FAQ, video, layanan lain) kini
// 100% deterministik per domain — konsisten antar crawl Google.
date_default_timezone_set('Asia/Bangkok');
$timestamp = date('Y-m-d H:i:s');
$dateDisplay = date('d F Y');

// Build title & description
$title = "{$BRAND} {$randomEmoji} {$randomTitleText}";
$desc  = "{$BRAND} - {$randomTagline}. {$randomDescText}";

// ============================================================
// 5. BUILD UNIQUE CONTENT PARTS
// ============================================================
$brandDisplay = htmlspecialchars($BRAND, ENT_QUOTES, 'UTF-8');
$brandLower = mb_strtolower($BRAND, 'UTF-8');
$destUrl = htmlspecialchars($destinationUrl, ENT_QUOTES, 'UTF-8');

// ============================================================
// 6. FAQ ITEMS (expanded for variety)
// ============================================================
$faqItems = [
    ["{$brandDisplay} คืออะไร?", "{$brandDisplay} เป็นหนึ่งในแพลตฟอร์มเกมออนไลน์ที่มีตัวเลือกเกมสนุกและความบันเทิงหลากหลาย แพลตฟอร์มนี้ถูกออกแบบมาเพื่อมอบประสบการณ์การเล่นที่ปลอดภัย สะดวกสบาย และสนุกสนานสำหรับผู้ใช้ทุกคน ด้วยการสนับสนุนของเทคโนโลยีที่ทันสมัย {$brandDisplay} เป็นตัวเลือกที่ดีที่สุดสำหรับคุณที่กำลังมองหาความบันเทิงที่มีคุณภาพ"],
    ["วิธีการเข้าร่วมกับ {$brandDisplay}?", "เพื่อเข้าร่วมกับ {$brandDisplay} คุณเพียงแค่กรอกแบบฟอร์มการสมัครที่มีอยู่ในหน้าแรก กระบวนการสมัครง่ายมากและใช้เวลาเพียงไม่กี่นาที หลังจากบัญชีของคุณเปิดใช้งานแล้ว คุณสามารถสนุกกับบริการทั้งหมดที่มีในแพลตฟอร์ม {$brandDisplay} ได้ทันที"],
    ["ข้อดีของ {$brandDisplay} คืออะไร?", "{$brandDisplay} มีข้อดีมากมาย เช่น: ระบบความปลอดภัยหลายชั้น กระบวนการธุรกรรมที่รวดเร็ว บริการลูกค้า 24 ชั่วโมง การแสดงผลที่ใช้งานง่าย และโบนัสที่น่าสนใจหลากหลาย {$brandDisplay} ยังคงสร้างนวัตกรรมอย่างต่อเนื่องเพื่อมอบประสบการณ์ที่ดีที่สุดสำหรับผู้ใช้ทุกคน"],
    ["{$brandDisplay} ปลอดภัยในการใช้งานหรือไม่?", "แน่นอน {$brandDisplay} ใช้ระบบเข้ารหัส SSL ล่าสุดเพื่อปกป้องข้อมูลส่วนตัวและธุรกรรมของคุณ ความปลอดภัยและความเป็นส่วนตัวของผู้ใช้เป็นสิ่งสำคัญสูงสุดของเรา {$brandDisplay} มุ่งมั่นที่จะจัดหาสภาพแวดล้อมการเล่นที่ปลอดภัยและน่าเชื่อถือสำหรับผู้ใช้ทุกคน"],
    ["วิธีการติดต่อฝ่ายสนับสนุนของ {$brandDisplay}?", "คุณสามารถติดต่อทีมสนับสนุนของ {$brandDisplay} ผ่านแชทสดที่มีให้บริการ 24 ชั่วโมง WhatsApp หรืออีเมล ทีมบริการลูกค้าสัมพันธ์ของเราที่เป็นกันเองและมืออาชีพพร้อมช่วยเหลือคุณด้วยคำถามหรือปัญหาใดๆ ที่คุณพบขณะใช้แพลตฟอร์ม {$brandDisplay}"],
    ["{$brandDisplay} มีเกมประเภทใดบ้าง?", "{$brandDisplay} มีเกมหลากหลายประเภทให้เลือกเล่น เช่น สล็อตออนไลน์ คาสิโนสด กีฬาเสมือนจริง เกมยิงปลา และหวยออนไลน์ ทุกเกมมาจากผู้ให้บริการชั้นนำและรับประกันความยุติธรรม 100%"],
    ["การฝาก-ถอนเงินกับ {$brandDisplay} ทำอย่างไร?", "{$brandDisplay} รองรับการฝาก-ถอนเงินผ่านหลายช่องทาง เช่น ธนาคารในประเทศ ทรูมันนี่ วอลเลท คิวอาร์โค้ด และคริปโทเคอร์เรนซี กระบวนการรวดเร็ว อัตโนมัติ และปลอดภัย ไม่มีค่าธรรมเนียม"],
    ["{$brandDisplay} มีโปรโมชั่นอะไรบ้าง?", "{$brandDisplay} มีโปรโมชั่นมากมาย เช่น โบนัสสมาชิกใหม่ 100% โบนัสฝากเงินรายวัน คืนยอดเสียรายสัปดาห์ ฟรีสปิน และโบนัสแนะนำเพื่อน ติดตามโปรโมชั่นล่าสุดได้ที่หน้าเว็บไซต์หลัก"],
];

// Select 4 FAQ items based on seed
$faqIdx1 = $seed % count($faqItems);
$faqIdx2 = ($seed + 11) % count($faqItems);
$faqIdx3 = ($seed + 22) % count($faqItems);
$faqIdx4 = ($seed + 33) % count($faqItems);
while ($faqIdx2 === $faqIdx1) { $faqIdx2 = ($faqIdx2 + 1) % count($faqItems); }
while ($faqIdx3 === $faqIdx1 || $faqIdx3 === $faqIdx2) { $faqIdx3 = ($faqIdx3 + 1) % count($faqItems); }
while ($faqIdx4 === $faqIdx1 || $faqIdx4 === $faqIdx2 || $faqIdx4 === $faqIdx3) { $faqIdx4 = ($faqIdx4 + 1) % count($faqItems); }

$selectedFaqs = [$faqItems[$faqIdx1], $faqItems[$faqIdx2], $faqItems[$faqIdx3], $faqItems[$faqIdx4]];

// ============================================================
// 7. FEATURED VIDEOS (pilih deterministik berdasarkan seed
//    agar sama konsisten per domain & tidak berubah tiap crawl)
// ============================================================
$vidOffset = ($seed + 7) % count($images);
$videoThumbnails = [];
for ($v = 0; $v < 4; $v++) {
    $videoThumbnails[] = $images[($vidOffset + $v * 3) % count($images)];
}

// ============================================================
// 8. SIDEBAR LINKS (other services — rotasi deterministik)
// ============================================================
$otherServices = [
    ['name' => 'สล็อตต่างประเทศ ยุโรป', 'emoji' => '🎰'],
    ['name' => 'ktvgame88', 'emoji' => '🎮'],
    ['name' => 'คูลฟีเวอร์', 'emoji' => '🔥'],
    ['name' => 'PG Soft', 'emoji' => '🎯'],
    ['name' => 'Pragmatic Play', 'emoji' => '🏆'],
];
$svcOffset = $seed % count($otherServices);
$rotatedServices = [];
for ($s = 0; $s < count($otherServices); $s++) {
    $rotatedServices[] = $otherServices[($svcOffset + $s) % count($otherServices)];
}
$otherServices = $rotatedServices;

?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="description" content="<?= htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="robots" content="index, follow">
    <meta name="author" content="<?= $brandDisplay ?>">
    <link rel="canonical" href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>">

    <!-- Open Graph -->
    <meta property="og:title" content="<?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:description" content="<?= htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:image" content="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:site_name" content="<?= $brandDisplay ?>">
    <meta property="og:locale" content="th_TH">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8') ?>">

    <!-- Structured Data: FAQ -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            <?php foreach ($selectedFaqs as $idx => $faq): ?>
            {
                "@type": "Question",
                "name": "<?= htmlspecialchars($faq[0], ENT_QUOTES, 'UTF-8') ?>",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "<?= htmlspecialchars($faq[1], ENT_QUOTES, 'UTF-8') ?>"
                }
            }<?= $idx < count($selectedFaqs) - 1 ? ',' : '' ?>
            <?php endforeach; ?>
        ]
    }
    </script>

    <!-- Structured Data: Product -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": "<?= $brandDisplay ?>",
        "description": "<?= htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') ?>",
        "image": "<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8') ?>",
        "offers": {
            "@type": "Offer",
            "price": "<?= str_replace(',', '', $randomPrice) ?>",
            "priceCurrency": "THB",
            "availability": "https://schema.org/InStock"
        }
    }
    </script>

    <style>
        /* ============================================================
           RESET & BASE
           ============================================================ */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; font-size: 16px; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Sarabun', 'Kanit', sans-serif;
            line-height: 1.8;
            color: #1a1a2e;
            background: #f8f9fa;
            -webkit-font-smoothing: antialiased;
        }
        a { color: #e94560; text-decoration: none; transition: color 0.2s; }
        a:hover { color: #c23152; text-decoration: underline; }
        img { max-width: 100%; height: auto; display: block; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 1.5rem; }

        /* ============================================================
           HEADER
           ============================================================ */
        .header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            color: #fff;
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 15px rgba(0,0,0,0.2);
        }
        .header .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .header__logo {
            font-size: 1.5rem;
            font-weight: 800;
            letter-spacing: -0.5px;
            color: #fff;
            text-decoration: none;
        }
        .header__logo span { color: #e94560; }
        .header__nav { display: flex; gap: 1.5rem; flex-wrap: wrap; }
        .header__nav a { color: #ccc; font-size: 0.9rem; font-weight: 500; }
        .header__nav a:hover { color: #e94560; text-decoration: none; }

        /* ============================================================
           HERO - PRODUCT STYLE
           ============================================================ */
        .hero {
            background: linear-gradient(135deg, #0f3460 0%, #16213e 50%, #1a1a2e 100%);
            color: #fff;
            padding: 3rem 1.5rem 2rem;
            text-align: center;
            border-bottom: 4px solid #e94560;
        }
        .hero__inner { max-width: 800px; margin: 0 auto; }
        .hero__emoji { font-size: 3.5rem; margin-bottom: 0.5rem; }
        .hero__title {
            font-size: 2.2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            line-height: 1.3;
        }
        .hero__title span { color: #e94560; }
        .hero__price {
            font-size: 2.5rem;
            font-weight: 700;
            color: #e94560;
            background: rgba(233, 69, 96, 0.15);
            display: inline-block;
            padding: 0.25rem 2rem;
            border-radius: 50px;
            margin: 0.5rem 0;
            border: 2px solid rgba(233, 69, 96, 0.3);
        }
        .hero__sku {
            font-size: 0.85rem;
            color: #888;
            margin-bottom: 0.5rem;
        }
        .hero__subtitle {
            font-size: 1.1rem;
            color: #ccc;
            margin-bottom: 1.5rem;
            max-width: 650px;
            margin-left: auto;
            margin-right: auto;
        }
        .hero__cta {
            display: inline-block;
            background: #e94560;
            color: #fff;
            padding: 0.85rem 3rem;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        .hero__cta:hover {
            background: #c23152;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(233,69,96,0.4);
            text-decoration: none;
            color: #fff;
        }

        /* Tombol Login + Daftar di Hero */
        .hero__auth {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 1.5rem;
        }
        .hero__auth-btn {
            flex: 1 1 200px;
            max-width: 220px;
            display: inline-block;
            padding: 1rem 1.5rem;
            border-radius: 50px;
            font-weight: 800;
            font-size: 1.15rem;
            letter-spacing: 0.3px;
            transition: all 0.3s;
        }
        .hero__auth-btn--green {
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: #fff;
            box-shadow: 0 6px 20px rgba(76,175,80,0.4);
        }
        .hero__auth-btn--blue {
            background: linear-gradient(135deg, #2196F3, #1565C0);
            color: #fff;
            box-shadow: 0 6px 20px rgba(33,150,243,0.4);
        }
        .hero__auth-btn:hover {
            transform: translateY(-3px);
            filter: brightness(1.1);
            color: #fff;
            text-decoration: none;
        }

        /* ============================================================
           MAIN LAYOUT
           ============================================================ */
        .main { padding: 2rem 1.5rem; }
        .main-grid {
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }
        @media (max-width: 768px) {
            .main-grid { grid-template-columns: 1fr; }
        }

        /* ============================================================
           CONTENT
           ============================================================ */
        .content h2 {
            font-size: 1.6rem;
            margin: 2rem 0 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 3px solid #e94560;
            display: inline-block;
        }
        .content h2:first-child { margin-top: 0; }
        .content p { margin-bottom: 1.2rem; color: #444; text-align: justify; }
        .content .highlight-box {
            background: linear-gradient(135deg, #fff5f5 0%, #ffe8ec 100%);
            border-left: 4px solid #e94560;
            padding: 1.2rem 1.5rem;
            border-radius: 0 8px 8px 0;
            margin: 1.5rem 0;
            font-weight: 500;
        }
        .content ul {
            margin: 1rem 0 1.5rem 1.5rem;
            color: #444;
        }
        .content ul li { margin-bottom: 0.4rem; }

        .steps {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin: 1.5rem 0;
        }
        .step {
            background: #fff;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            text-align: center;
            border-top: 4px solid #e94560;
        }
        .step__num {
            display: inline-block;
            background: #e94560;
            color: #fff;
            width: 36px;
            height: 36px;
            line-height: 36px;
            border-radius: 50%;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        .step h4 { margin-bottom: 0.3rem; color: #1a1a2e; }
        .step p { font-size: 0.9rem; color: #666; margin: 0; text-align: center; }

        /* ============================================================
           SIDEBAR
           ============================================================ */
        .sidebar__cta {
            display: block;
            background: linear-gradient(135deg, #e94560, #c23152);
            color: #fff;
            text-align: center;
            padding: 1rem;
            border-radius: 12px;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.3s;
            margin-bottom: 1.5rem;
        }
        .sidebar__cta:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(233,69,96,0.3);
            text-decoration: none;
            color: #fff;
        }

        /* Tombol Login + Daftar di Sidebar */
        .sidebar__auth {
            display: flex;
            gap: 0.6rem;
            margin-bottom: 0.8rem;
        }
        .sidebar__auth-btn {
            flex: 1;
            display: block;
            text-align: center;
            padding: 0.9rem 0.4rem;
            border-radius: 50px;
            font-weight: 800;
            font-size: 0.95rem;
            color: #fff;
            transition: all 0.3s;
        }
        .sidebar__auth-btn--green {
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            box-shadow: 0 4px 14px rgba(76,175,80,0.35);
        }
        .sidebar__auth-btn--blue {
            background: linear-gradient(135deg, #2196F3, #1565C0);
            box-shadow: 0 4px 14px rgba(33,150,243,0.35);
        }
        .sidebar__auth-btn:hover {
            transform: translateY(-2px);
            filter: brightness(1.1);
            color: #fff;
            text-decoration: none;
        }
        .sidebar__card {
            background: #fff;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
        }
        .sidebar__card h3 {
            font-size: 1.1rem;
            margin-bottom: 0.75rem;
            color: #1a1a2e;
        }
        .sidebar__card ul { list-style: none; }
        .sidebar__card ul li {
            padding: 0.4rem 0;
            border-bottom: 1px solid #f0f0f0;
            font-size: 0.9rem;
        }
        .sidebar__card ul li:last-child { border-bottom: none; }
        .sidebar__card ul li::before {
            content: '✓ ';
            color: #28a745;
            font-weight: bold;
        }
        .sidebar__img {
            border-radius: 12px;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .sidebar__service-link {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 0;
            border-bottom: 1px solid #f0f0f0;
            color: #1a1a2e;
            font-size: 0.9rem;
        }
        .sidebar__service-link:last-child { border-bottom: none; }
        .sidebar__service-link:hover { color: #e94560; text-decoration: none; }

        /* ============================================================
           VIDEO SECTION
           ============================================================ */
        .video-section {
            margin-top: 2rem;
        }
        .video-section h2 {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .video-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
        }
        .video-card {
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            transition: transform 0.3s;
        }
        .video-card:hover { transform: translateY(-4px); }
        .video-card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
        }
        .video-card .video-info {
            padding: 0.8rem 1rem;
            text-align: center;
        }
        .video-card .video-info a {
            font-weight: 600;
            color: #1a1a2e;
            font-size: 0.85rem;
            display: block;
            margin-top: 0.3rem;
        }
        .video-card .video-info a:hover { color: #e94560; text-decoration: none; }
        .video-card .video-btn {
            display: inline-block;
            background: #e94560;
            color: #fff;
            padding: 0.3rem 1.5rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
            transition: all 0.3s;
        }
        .video-card .video-btn:hover {
            background: #c23152;
            color: #fff;
            text-decoration: none;
        }

        /* ============================================================
           FAQ
           ============================================================ */
        .faq-section { margin-top: 2rem; }
        .faq-section h2 {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .faq-item {
            background: #fff;
            border-radius: 10px;
            margin-bottom: 0.75rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            overflow: hidden;
        }
        .faq-item summary {
            padding: 1rem 1.5rem;
            font-weight: 600;
            cursor: pointer;
            color: #1a1a2e;
            display: flex;
            justify-content: space-between;
            align-items: center;
            user-select: none;
        }
        .faq-item summary:hover { color: #e94560; }
        .faq-item summary::after {
            content: '+';
            font-size: 1.3rem;
            font-weight: 300;
            color: #999;
            transition: transform 0.2s;
        }
        .faq-item[open] summary::after { content: '−'; color: #e94560; }
        .faq-item .faq-answer {
            padding: 0 1.5rem 1.2rem;
            color: #555;
            font-size: 0.95rem;
            line-height: 1.8;
        }

        /* ============================================================
           FOOTER
           ============================================================ */
        .footer {
            background: #1a1a2e;
            color: #888;
            text-align: center;
            padding: 2rem 1.5rem;
            font-size: 0.85rem;
            margin-top: 3rem;
        }
        .footer a { color: #e94560; }
        .footer__disclaimer {
            max-width: 700px;
            margin: 0.75rem auto 0;
            font-size: 0.8rem;
            color: #666;
        }
        .footer__links {
            display: flex;
            justify-content: center;
            gap: 2rem;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }
        .footer__links a { color: #888; font-size: 0.85rem; }
        .footer__links a:hover { color: #e94560; text-decoration: none; }

        /* ============================================================
           POPUP FOOTER — GAMBAR BESAR + CTA
           ============================================================ */
        .popup {
            position: fixed;
            inset: 0;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        .popup__overlay {
            position: absolute;
            inset: 0;
            background: rgba(0, 0, 0, 0.8);
        }
        .popup__box {
            position: relative;
            background: #fff;
            border-radius: 16px;
            max-width: 420px;
            width: 100%;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.5);
            animation: popupIn 0.4s ease;
            max-height: 90vh;
            overflow-y: auto;
        }
        @keyframes popupIn {
            from { transform: translateY(40px); opacity: 0; }
            to   { transform: translateY(0);   opacity: 1; }
        }
        .popup__close {
            position: absolute;
            top: 0.75rem;
            right: 0.75rem;
            width: 34px;
            height: 34px;
            border-radius: 50%;
            border: none;
            background: #f0f0f0;
            color: #333;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .popup__close:hover { background: #e94560; color: #fff; }
        .popup__brand {
            font-size: 1.4rem;
            font-weight: 800;
            color: #1a1a2e;
            margin-bottom: 0.25rem;
        }
        .popup__brand span { color: #e94560; }
        .popup__head {
            font-size: 1.1rem;
            font-weight: 700;
            color: #e94560;
            margin-bottom: 1rem;
        }
        .popup__img {
            width: 100%;
            border-radius: 12px;
            margin-bottom: 1rem;
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
            transition: transform 0.3s;
        }
        .popup__img:hover { transform: scale(1.03); }
        .popup__slogan {
            font-size: 0.95rem;
            color: #555;
            margin-bottom: 1rem;
        }
        .popup__cta-row {
            display: flex;
            gap: 0.7rem;
        }
        .popup__cta {
            flex: 1;
            background: linear-gradient(135deg, #2196F3, #1976D2);
            color: #fff;
            padding: 0.95rem 0.5rem;
            border-radius: 50px;
            font-weight: 800;
            font-size: 1.05rem;
            text-align: center;
            transition: all 0.3s;
        }
        .popup__cta--green { background: linear-gradient(135deg, #4CAF50, #388E3C); }
        .popup__cta:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(33,150,243,0.4);
            color: #fff;
            text-decoration: none;
        }
        .popup__cta--green:hover { box-shadow: 0 8px 25px rgba(76,175,80,0.4); }
    </style>
</head>
<body>

<!-- ============================================================
HEADER
============================================================ -->
<header class="header">
    <div class="container">
        <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>" class="header__logo">
            <?= $brandDisplay ?> <span><?= $randomEmoji ?></span>
        </a>
        <nav class="header__nav">
            <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>">หน้าแรก</a>
            <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>#เกี่ยวกับ">เกี่ยวกับ</a>
            <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>#faq">คำถามที่พบบ่อย</a>
            <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>#ติดต่อ">ติดต่อ</a>
        </nav>
    </div>
</header>

<!-- ============================================================
HERO - PRODUCT STYLE
============================================================ -->
<section class="hero">
    <div class="hero__inner">
        <div class="hero__emoji"><?= $randomEmoji ?></div>
        <h1 class="hero__title"><?= $brandDisplay ?> <span><?= htmlspecialchars($randomTagline, ENT_QUOTES, 'UTF-8') ?></span></h1>
        <div class="hero__price">฿ <?= $randomPrice ?></div>
        <div class="hero__sku">SKU: <?= $randomSKU ?></div>
        <p class="hero__subtitle"><?= htmlspecialchars($randomDescText, ENT_QUOTES, 'UTF-8') ?></p>
        <a href="<?= $destUrl ?>" class="hero__cta" rel="nofollow">เรียนรู้เพิ่มเติม</a>

        <!-- Login + Daftar -->
        <div class="hero__auth">
            <a href="<?= $destUrl ?>" class="hero__auth-btn hero__auth-btn--green" rel="nofollow">เข้าสู่ระบบ</a>
            <a href="<?= $destUrl ?>" class="hero__auth-btn hero__auth-btn--blue" rel="nofollow">สมัครสมาชิก</a>
        </div>
    </div>
</section>

<!-- ============================================================
MAIN CONTENT
============================================================ -->
<main class="main">
    <div class="main-grid">

        <!-- ===== CONTENT AREA ===== -->
        <div class="content">

            <!-- About Section -->
            <section id="เกี่ยวกับ">
                <h2>เกี่ยวกับ <?= $brandDisplay ?></h2>
                <p><?= htmlspecialchars($contentBlock1, ENT_QUOTES, 'UTF-8') ?></p>
                <p><?= htmlspecialchars($contentBlock2, ENT_QUOTES, 'UTF-8') ?></p>

                <div class="highlight-box">
                    <strong><?= $randomEmoji ?> ทำไมต้องเลือก <?= $brandDisplay ?>?</strong><br>
                    <?= $brandDisplay ?> เป็น <?= htmlspecialchars($randomTagline, ENT_QUOTES, 'UTF-8') ?> ที่มอบประสบการณ์ที่ดีที่สุดด้วยการสนับสนุนเทคโนโลยีที่ทันสมัย ระบบความปลอดภัยที่น่าเชื่อถือ และบริการมืออาชีพตลอด 24 ชั่วโมง
                </div>

                <p><?= htmlspecialchars($contentBlock3, ENT_QUOTES, 'UTF-8') ?></p>

                <!-- Benefits List -->
                <h3>จุดเด่นของ <?= $brandDisplay ?></h3>
                <ul>
                    <li>เข้าถึงง่ายและรวดเร็วผ่านทุกอุปกรณ์</li>
                    <li>ความปลอดภัยของข้อมูลรับประกันด้วยระบบ SSL</li>
                    <li>บริการลูกค้า 24 ชั่วโมงไม่หยุด</li>
                    <li>กระบวนการธุรกรรมที่รวดเร็วทันใจ</li>
                    <li>รองรับหลายภาษาและหลายสกุลเงิน</li>
                    <li>โบนัสและโปรโมชั่นมากมายทุกวัน</li>
                </ul>

                <!-- Steps -->
                <h3>วิธีการเริ่มต้นกับ <?= $brandDisplay ?></h3>
                <div class="steps">
                    <div class="step">
                        <div class="step__num">1</div>
                        <h4>สมัครสมาชิก</h4>
                        <p>กรอกแบบฟอร์มสมัครสมาชิกให้ครบถ้วน</p>
                    </div>
                    <div class="step">
                        <div class="step__num">2</div>
                        <h4>ยืนยันตัวตน</h4>
                        <p>ยืนยันข้อมูลเพื่อเปิดใช้งานบัญชี</p>
                    </div>
                    <div class="step">
                        <div class="step__num">3</div>
                        <h4>เริ่มเล่น</h4>
                        <p>ฝากเงินและเริ่มเล่นเกมโปรดของคุณ</p>
                    </div>
                </div>

                <div style="text-align:center;margin:2rem 0;">
                    <a href="<?= $destUrl ?>" rel="nofollow" style="display:inline-block;background:linear-gradient(135deg,#e94560,#c23152);color:#fff;padding:0.9rem 3rem;border-radius:50px;font-weight:700;font-size:1.05rem;text-decoration:none;transition:all 0.3s;" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 25px rgba(233,69,96,0.4)'" onmouseout="this.style.transform='';this.style.boxShadow=''">เข้าใช้ <?= $brandDisplay ?> เลย</a>
                </div>
            </section>

            <!-- ===== FEATURED VIDEOS ===== -->
            <section class="video-section" id="วิดีโอ">
                <h2>🎥 คลิปแนะนำ</h2>
                <div class="video-grid">
                    <?php foreach ($videoThumbnails as $idx => $thumb): ?>
                    <div class="video-card">
                        <a href="<?= $destUrl ?>" rel="nofollow" aria-label="รับชม">
                            <img src="<?= htmlspecialchars($thumb, ENT_QUOTES, 'UTF-8') ?>" alt="วิดีโอแนะนำ <?= $brandDisplay ?>" loading="lazy">
                        </a>
                        <div class="video-info">
                            <span class="video-btn">รับชม</span>
                            <a href="<?= $destUrl ?>" rel="nofollow">คลิปแนะนำ <?= $brandDisplay ?> #<?= $idx + 1 ?></a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- ===== FAQ ===== -->
            <section class="faq-section" id="faq">
                <h2>❓ คำถามที่พบบ่อยเกี่ยวกับ <?= $brandDisplay ?></h2>
                <?php foreach ($selectedFaqs as $faq): ?>
                <details class="faq-item">
                    <summary><?= htmlspecialchars($faq[0], ENT_QUOTES, 'UTF-8') ?></summary>
                    <div class="faq-answer">
                        <p><?= htmlspecialchars($faq[1], ENT_QUOTES, 'UTF-8') ?></p>
                    </div>
                </details>
                <?php endforeach; ?>
            </section>
        </div>

        <!-- ===== SIDEBAR ===== -->
        <aside class="sidebar">
            <div class="sidebar__auth">
                <a href="<?= $destUrl ?>" class="sidebar__auth-btn sidebar__auth-btn--green" rel="nofollow">เข้าสู่ระบบ</a>
                <a href="<?= $destUrl ?>" class="sidebar__auth-btn sidebar__auth-btn--blue" rel="nofollow">สมัครสมาชิก</a>
            </div>

            <a href="<?= $destUrl ?>" class="sidebar__cta" rel="nofollow">สมัคร <?= $brandDisplay ?> เลย</a>

            <a href="<?= $destUrl ?>" rel="nofollow" aria-label="สมัครสมาชิก">
                <img src="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8') ?>" alt="<?= $brandDisplay ?>" class="sidebar__img" loading="lazy" width="320" height="320">
            </a>

            <div class="sidebar__card">
                <h3>ข้อดีของ <?= $brandDisplay ?></h3>
                <ul>
                    <li>เข้าถึงง่ายและรวดเร็ว</li>
                    <li>ความปลอดภัยของข้อมูลรับประกัน</li>
                    <li>บริการ 24 ชั่วโมงไม่หยุด</li>
                    <li>กระบวนการธุรกรรมที่รวดเร็ว</li>
                    <li>รองรับหลายอุปกรณ์</li>
                    <li>การแสดงผลที่ใช้งานง่าย</li>
                </ul>
            </div>

            <div class="sidebar__card">
                <h3>📌 บริการอื่นๆ</h3>
                <?php foreach ($otherServices as $service): ?>
                <a href="<?= $destUrl ?>" rel="nofollow" class="sidebar__service-link">
                    <?= $service['emoji'] ?> <?= $service['name'] ?>
                </a>
                <?php endforeach; ?>
            </div>

            <div class="sidebar__card">
                <h3>📞 ติดต่อและสนับสนุน</h3>
                <ul>
                    <li>แชทสด 24 ชั่วโมง</li>
                    <li>สนับสนุนทาง WhatsApp</li>
                    <li>อีเมลช่วยเหลือ</li>
                    <li>Telegram ทางการ</li>
                </ul>
            </div>
        </aside>

    </div>
</main>

<!-- ============================================================
FOOTER
============================================================ -->
<footer class="footer" id="ติดต่อ">
    <div class="container">
        <div class="footer__links">
            <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>">หน้าแรก</a>
            <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>#เกี่ยวกับ">เกี่ยวกับ</a>
            <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>#faq">คำถามที่พบบ่อย</a>
            <a href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>#วิดีโอ">คลิปแนะนำ</a>
        </div>
        <p>&copy; <?= date('Y') ?> <?= $brandDisplay ?>. สงวนลิขสิทธิ์ทั้งหมด</p>
        <p class="footer__disclaimer">
            หน้านี้ให้ข้อมูลทั่วไปเกี่ยวกับ <?= $brandDisplay ?> 
            เนื้อหาในหน้านี้มีวัตถุประสงค์เพื่อให้ข้อมูลเท่านั้น 
            <?= $brandDisplay ?> เป็น <?= htmlspecialchars($randomTagline, ENT_QUOTES, 'UTF-8') ?>
            อัปเดตล่าสุด: <?= $dateDisplay ?>
        </p>
    </div>
</footer>

<!-- ============================================================
POPUP FOOTER — GAMBAR BESAR (SEED DOMAIN-AWARE) + CTA
============================================================ -->
<div class="popup" id="popupFooter" style="display:none;">
    <div class="popup__overlay" onclick="closeFooterPopup()"></div>
    <div class="popup__box">
        <button class="popup__close" onclick="closeFooterPopup()" aria-label="ปิด">✕</button>
        <div class="popup__brand"><?= $brandDisplay ?> <span><?= $randomEmoji ?></span></div>
        <div class="popup__head">🎁 โปรโมชั่นพิเศษวันนี้</div>
        <a href="<?= $destUrl ?>" rel="nofollow" aria-label="สมัครสมาชิก">
            <img class="popup__img" src="<?= htmlspecialchars($popupImg, ENT_QUOTES, 'UTF-8') ?>" alt="โปรโมชั่น <?= $brandDisplay ?>" width="420" height="420">
        </a>
        <div class="popup__slogan"><?= htmlspecialchars($randomTagline, ENT_QUOTES, 'UTF-8') ?> — รับโบนัสสูงสุดทันที</div>
        <div class="popup__cta-row">
            <a href="<?= $destUrl ?>" class="popup__cta popup__cta--green" rel="nofollow">เข้าสู่ระบบ</a>
            <a href="<?= $destUrl ?>" class="popup__cta" rel="nofollow">สมัครสมาชิก</a>
        </div>
    </div>
</div>

<script>
    function closeFooterPopup() {
        document.getElementById('popupFooter').style.display = 'none';
    }
    // Popup selalu muncul setiap kali halaman dimuat / di-refresh
    document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('popupFooter').style.display = 'flex';
    });
</script>

</body>
</html>